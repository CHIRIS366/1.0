npm install -D tailwindcss postcss postcss-cli autoprefixer concurrently
npx tailwindcss init
