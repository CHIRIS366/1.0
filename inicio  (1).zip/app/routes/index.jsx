cd <directory>
npm create @shopify/hydrogen@latest
